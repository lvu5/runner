using UnityEngine;

namespace InfiniteRunner
{
    /// <summary>
    /// Converts normalized body landmarks into stable runner commands. Gesture
    /// recognition stays in C# so Web and a future native iOS pose provider use
    /// identical calibration and tuning.
    /// </summary>
    internal sealed class PoseGestureRecognizer
    {
        private const float CalibrationSeconds = 1.2f;
        private const int MinimumCalibrationSamples = 12;

        private const float MinimumJumpBodyRise = 0.11f;
        private const float MaximumJumpBodyRise = 0.27f;
        private const float MinimumJumpFeetRise = 0.035f;
        private const float MaximumJumpFeetRise = 0.12f;

        private const float PoseFilterSeconds = 0.045f;
        private const float LaneFilterSeconds = 0.10f;
        private const float JumpConfirmationSeconds = 0.025f;
        private const float JumpBufferSeconds = 0.18f;
        private const float LandingConfirmationSeconds = 0.09f;
        private const float CrouchConfirmationSeconds = 0.05f;
        private const float StandConfirmationSeconds = 0.075f;

        private const float LeftZoneBoundary = 1f / 3f;
        private const float RightZoneBoundary = 2f / 3f;
        private const float ZoneHysteresis = 0.018f;
        private const float ZoneConfirmationSeconds = 0.045f;
        private const float LaneChangeRunGrace = 1f;

        private const float MinimumStepKneeLift = 0.045f;
        private const float MaximumStepKneeLift = 0.11f;
        private const float MinimumStepAnkleLift = 0.05f;
        private const float MaximumStepAnkleLift = 0.12f;
        private const float MinimumStepKneeAngle = 150f;
        private const float MaximumStepKneeAngle = 172f;
        private const float MinimumStepSideDifference = 0.012f;
        private const float MaximumStepSideDifference = 0.04f;
        private const float StepCadenceMinimum = 0.1f;
        private const float StepCadenceMaximum = 1.15f;
        private const float FirstStepRunGrace = 1.2f;
        private const float AlternatingRunGrace = 1.2f;
        private const float JumpRunGrace = 1.05f;

        private BodyPoseSnapshot smoothed;
        private BodyPoseSnapshot calibrationSum;
        private BodyPoseSnapshot baseline;
        private BodyPoseSnapshot calibrationAnchor;
        private float lastPoseAt = -100f;
        private float jumpCandidateAt = -1f;
        private float landingCandidateAt = -1f;
        private float crouchCandidateAt = -1f;
        private float standCandidateAt = -1f;
        private float lastJumpAt = -100f;
        private float lastLandingAt = -100f;
        private float pendingJumpUntil = -100f;
        private bool jumpArmed;
        private bool hasSmoothedPose;
        private bool calibrationStarted;
        private float calibrationStartedAt;
        private int calibrationSamples;

        private bool jumpPoseActive;
        private bool crouchHeld;
        private bool crouchMaintainsRun;
        private int stableBodyLane = -1;
        private int candidateBodyLane = -1;
        private float candidateBodyLaneStartedAt;
        private int raisedLegState;
        private int lastStepSide;
        private float lastStepAt = -100f;
        private float runUntil = -100f;
        private bool pendingJump;
        private string lastGesture = "Stand neutral";
        private float runSensitivity = 0.65f;
        private float jumpSensitivity = 0.65f;
        private float crouchSensitivity = 0.65f;

        public bool IsCalibrated { get; private set; }
        public bool IsCenteredForCalibration { get; private set; }
        public float CalibrationProgress01 { get; private set; }
        public bool CrouchHeld => IsCalibrated && crouchHeld;
        public int TargetLane { get; private set; } = -1;
        public string LastGesture => lastGesture;

        public bool IsRunHeld(float now)
        {
            return IsCalibrated && now <= runUntil;
        }

        public void SetSensitivities(float run, float jump, float crouch = 0.65f)
        {
            if (!float.IsNaN(run) && !float.IsInfinity(run))
            {
                runSensitivity = Mathf.Clamp01(run);
            }

            if (!float.IsNaN(jump) && !float.IsInfinity(jump))
            {
                jumpSensitivity = Mathf.Clamp01(jump);
            }
            if (!float.IsNaN(crouch) && !float.IsInfinity(crouch))
                crouchSensitivity = Mathf.Clamp01(crouch);
        }

        public void Process(BodyPoseSnapshot pose, float now)
        {
            if (now <= lastPoseAt) return;
            float dt = Mathf.Clamp(now - lastPoseAt, 1f / 120, 0.2f);
            if (hasSmoothedPose && now - lastPoseAt > 0.25f) LoseTracking();
            lastPoseAt = now;
            if (!hasSmoothedPose)
            {
                smoothed = pose;
                hasSmoothedPose = true;
            }
            else
            {
                float previousCenter = smoothed.BodyCenterX;
                smoothed = BodyPoseSnapshot.Lerp(smoothed, pose, 1f - Mathf.Exp(-dt / PoseFilterSeconds));
                smoothed.BodyCenterX = Mathf.Lerp(previousCenter, pose.BodyCenterX, 1f - Mathf.Exp(-dt / LaneFilterSeconds));
            }

            if (!IsCalibrated)
            {
                IsCenteredForCalibration = ZoneFromPosition(pose.BodyCenterX) == 1;
                CollectCalibrationSample(pose, now);
                return;
            }

            // Horizontal pose samples are especially noisy while stepping. Use
            // the filtered torso position for lane selection so a single camera
            // sample cannot whip the runner back toward the previous lane.
            bool laneChanged = UpdateBodyZone(smoothed.BodyCenterX, now);
            RecognizeGestures(pose, now, laneChanged);
        }

        public void Tick(float now)
        {
            if (now > pendingJumpUntil) pendingJump = false;
            if (crouchHeld && crouchMaintainsRun)
            {
                runUntil = Mathf.Max(runUntil, now + 0.25f);
            }
        }

        public bool ConsumeJump(float now)
        {
            bool value = pendingJump && now <= pendingJumpUntil;
            pendingJump = false;
            return value;
        }

        public void ResetCalibration()
        {
            IsCalibrated = false;
            IsCenteredForCalibration = false;
            CalibrationProgress01 = 0f;
            calibrationStarted = false;
            calibrationSamples = 0;
            calibrationSum = default;
            hasSmoothedPose = false;
            ClearTransientState();
            ResetBodyZone();
            lastGesture = "Move into center";
        }

        public void LoseTracking()
        {
            hasSmoothedPose = false;
            if (!IsCalibrated)
            {
                ResetCalibrationCollection();
                IsCenteredForCalibration = false;
            }

            ClearTransientState();
            ResetBodyZone();
        }

        public void ClearBufferedActions(float now)
        {
            ClearTransientState();
        }

        public string CurrentAction(float now) => !IsCalibrated ? lastGesture :
            jumpPoseActive || now - lastJumpAt < 0.35f ? "Jump" :
            crouchHeld ? "Crouch" : IsRunHeld(now) ? "Run" : "Ready";

        private void CollectCalibrationSample(BodyPoseSnapshot pose, float now)
        {
            if (smoothed.TorsoHeight < 0.045f || smoothed.ShoulderWidth < 0.045f)
            {
                ResetCalibrationCollection();
                IsCenteredForCalibration = false;
                lastGesture = "Show your full body";
                return;
            }

            if (!IsCenteredForCalibration)
            {
                ResetCalibrationCollection();
                hasSmoothedPose = false;
                lastGesture = "Move into center";
                return;
            }

            bool upright = KneeAngle(pose.LeftHip, pose.LeftKnee, pose.LeftAnkle) > 158f &&
                           KneeAngle(pose.RightHip, pose.RightKnee, pose.RightAnkle) > 158f &&
                           pose.HipCenter.y > pose.ShoulderCenter.y + 0.045f &&
                           pose.AnkleCenter.y > pose.HipCenter.y + 0.12f;
            float stillTolerance = Mathf.Max(0.006f, pose.TorsoHeight * 0.08f);
            bool moved = calibrationStarted &&
                (Vector2.Distance(pose.HipCenter, calibrationAnchor.HipCenter) > stillTolerance ||
                 Vector2.Distance(pose.ShoulderCenter, calibrationAnchor.ShoulderCenter) > stillTolerance ||
                 Vector2.Distance(pose.LeftAnkle, calibrationAnchor.LeftAnkle) > stillTolerance ||
                 Vector2.Distance(pose.RightAnkle, calibrationAnchor.RightAnkle) > stillTolerance);
            if (!upright || moved)
            {
                ResetCalibrationCollection();
                lastGesture = upright ? "Keep still" : "Stand upright";
                return;
            }

            if (!calibrationStarted)
            {
                calibrationStarted = true;
                calibrationStartedAt = now;
                calibrationAnchor = pose;
                calibrationSamples = 0;
                calibrationSum = default;
            }

            calibrationSum += pose;
            lastGesture = "Keep still";
            calibrationSamples++;
            CalibrationProgress01 = Mathf.Clamp01((now - calibrationStartedAt) / CalibrationSeconds);

            if (CalibrationProgress01 < 1f || calibrationSamples < MinimumCalibrationSamples)
            {
                return;
            }

            baseline = calibrationSum / calibrationSamples;
            IsCalibrated = true;
            CalibrationProgress01 = 1f;
            lastGesture = "Ready";
            ClearTransientState();
            jumpArmed = true;
            stableBodyLane = 1;
            TargetLane = 1;
        }

        private void RecognizeGestures(BodyPoseSnapshot raw, float now, bool laneChanged)
        {
            float torso = Mathf.Max(0.045f, baseline.TorsoHeight);

            float hipRise = (baseline.HipCenter.y - smoothed.HipCenter.y) / torso;
            float shoulderRise = (baseline.ShoulderCenter.y - smoothed.ShoulderCenter.y) / torso;
            float leftAnkleRise = (baseline.LeftAnkle.y - smoothed.LeftAnkle.y) / torso;
            float rightAnkleRise = (baseline.RightAnkle.y - smoothed.RightAnkle.y) / torso;
            // A sideways step can briefly hide a leg from MediaPipe. Once the
            // player is already running, keep that run alive while a lane change
            // is being confirmed instead of treating it as a stop.
            if ((laneChanged || candidateBodyLane >= 0) && IsRunHeld(now))
            {
                runUntil = Mathf.Max(runUntil, now + LaneChangeRunGrace);
            }

            float jumpBodyRise = Mathf.Lerp(MaximumJumpBodyRise, MinimumJumpBodyRise, jumpSensitivity);
            float jumpFeetRise = Mathf.Lerp(MaximumJumpFeetRise, MinimumJumpFeetRise, jumpSensitivity);
            float rawHipRise = (baseline.HipCenter.y - raw.HipCenter.y) / torso;
            float rawShoulderRise = (baseline.ShoulderCenter.y - raw.ShoulderCenter.y) / torso;
            float rawLeftFootRise = (baseline.LeftAnkle.y - raw.LeftAnkle.y) / torso;
            float rawRightFootRise = (baseline.RightAnkle.y - raw.RightAnkle.y) / torso;
            // Require agreement from torso and BOTH feet, including the current unfiltered frame.
            // This rejects knee lifts and one-frame spikes without blocking real sideways jumps.
            bool jumpNow = hipRise > jumpBodyRise && shoulderRise > jumpBodyRise * 0.65f &&
                           Mathf.Min(leftAnkleRise, rightAnkleRise) > jumpFeetRise &&
                           rawHipRise > jumpBodyRise && rawShoulderRise > jumpBodyRise * 0.65f &&
                           Mathf.Min(rawLeftFootRise, rawRightFootRise) > jumpFeetRise;
            if (jumpArmed && jumpNow && now - lastJumpAt > 0.28f)
            {
                if (jumpCandidateAt < 0) jumpCandidateAt = now;
                if (now - jumpCandidateAt >= JumpConfirmationSeconds)
                {
                    bool wasRunning = IsRunHeld(now);
                    pendingJump = true;
                    pendingJumpUntil = now + JumpBufferSeconds;
                    lastJumpAt = now;
                    jumpArmed = false;
                    jumpPoseActive = true;
                    landingCandidateAt = -1;
                    crouchHeld = false;
                    crouchMaintainsRun = false;
                    lastGesture = "Jump";
                    if (wasRunning) runUntil = Mathf.Max(runUntil, now + JumpRunGrace);
                }
            }
            else jumpCandidateAt = -1;

            bool landed = hipRise < jumpBodyRise * 0.45f &&
                          Mathf.Max(leftAnkleRise, rightAnkleRise) < jumpFeetRise * 0.55f &&
                          Mathf.Max(rawLeftFootRise, rawRightFootRise) < jumpFeetRise * 0.55f;
            if (!jumpArmed && landed)
            {
                if (landingCandidateAt < 0) landingCandidateAt = now;
                if (now - landingCandidateAt >= LandingConfirmationSeconds)
                {
                    if (jumpPoseActive)
                    {
                        lastLandingAt = now;
                        // The next running step may use either foot. Do not compare it with
                        // the raised leg from before the jump or require a captured neutral frame.
                        raisedLegState = 0;
                        lastStepSide = 0;
                        lastStepAt = -100f;
                    }
                    jumpPoseActive = false;
                    jumpArmed = true;
                    jumpCandidateAt = -1;
                }
            }
            else landingCandidateAt = -1;

            float crouchHipEnter = Mathf.Lerp(0.28f, 0.10f, crouchSensitivity);
            float crouchShoulderEnter = Mathf.Lerp(0.18f, 0.07f, crouchSensitivity);
            float hipDrop = -hipRise;
            float shoulderDrop = -shoulderRise;
            // A front-facing squat can have nearly straight 2D knee angles. Use the sustained
            // lowering of hips AND shoulders with feet on the floor, not an unreliable angle gate.
            bool crouchEnter = !jumpPoseActive && now - lastLandingAt > 0.14f &&
                               hipDrop > crouchHipEnter && shoulderDrop > crouchShoulderEnter &&
                               -rawHipRise > crouchHipEnter * 0.8f &&
                               -rawShoulderRise > crouchShoulderEnter * 0.8f &&
                               Mathf.Max(leftAnkleRise, rightAnkleRise) < 0.14f;
            bool crouchExit = hipDrop < crouchHipEnter * 0.5f && shoulderDrop < crouchShoulderEnter * 0.6f;
            if (!crouchHeld && crouchEnter)
            {
                if (crouchCandidateAt < 0) crouchCandidateAt = now;
                if (now - crouchCandidateAt >= CrouchConfirmationSeconds)
                {
                    crouchMaintainsRun = IsRunHeld(now);
                    crouchHeld = true;
                    standCandidateAt = -1;
                    lastGesture = "Crouch";
                }
            }
            else crouchCandidateAt = -1;

            if (crouchHeld && crouchExit)
            {
                if (standCandidateAt < 0) standCandidateAt = now;
                if (now - standCandidateAt >= StandConfirmationSeconds)
                {
                    crouchHeld = false;
                    if (crouchMaintainsRun) runUntil = Mathf.Max(runUntil, now + FirstStepRunGrace);
                    crouchMaintainsRun = false;
                    lastGesture = "Ready";
                }
            }
            else standCandidateAt = -1;

            if (!jumpPoseActive && !crouchHeld)
            {
                RecognizeRunStep(leftAnkleRise, rightAnkleRise, torso, now);
            }
        }

        private bool UpdateBodyZone(float bodyCenterX, float now)
        {
            int desiredLane = ZoneWithHysteresis(bodyCenterX, stableBodyLane);
            if (stableBodyLane < 0)
            {
                CommitBodyLane(desiredLane, now);
                return true;
            }

            if (desiredLane == stableBodyLane)
            {
                candidateBodyLane = -1;
                TargetLane = stableBodyLane;
                return false;
            }

            if (desiredLane != candidateBodyLane)
            {
                candidateBodyLane = desiredLane;
                candidateBodyLaneStartedAt = now;
                return false;
            }

            if (now - candidateBodyLaneStartedAt < ZoneConfirmationSeconds)
            {
                return false;
            }

            CommitBodyLane(desiredLane, now);
            return true;
        }

        private void CommitBodyLane(int lane, float now)
        {
            stableBodyLane = lane;
            candidateBodyLane = -1;
            TargetLane = lane;
            lastGesture = lane == 0 ? "Left section" : lane == 2 ? "Right section" : "Center section";
        }

        private static int ZoneWithHysteresis(float position, int currentLane)
        {
            switch (currentLane)
            {
                case 0:
                    if (position > RightZoneBoundary + ZoneHysteresis)
                    {
                        return 2;
                    }

                    return position > LeftZoneBoundary + ZoneHysteresis ? 1 : 0;
                case 2:
                    if (position < LeftZoneBoundary - ZoneHysteresis)
                    {
                        return 0;
                    }

                    return position < RightZoneBoundary - ZoneHysteresis ? 1 : 2;
                default:
                    if (position < LeftZoneBoundary - ZoneHysteresis)
                    {
                        return 0;
                    }

                    return position > RightZoneBoundary + ZoneHysteresis ? 2 : 1;
            }
        }

        private static int ZoneFromPosition(float position)
        {
            return position < LeftZoneBoundary ? 0 : position > RightZoneBoundary ? 2 : 1;
        }

        private void ResetCalibrationCollection()
        {
            calibrationStarted = false;
            calibrationSamples = 0;
            calibrationSum = default;
            CalibrationProgress01 = 0f;
        }

        private void ResetBodyZone()
        {
            stableBodyLane = -1;
            candidateBodyLane = -1;
            candidateBodyLaneStartedAt = 0f;
            TargetLane = -1;
        }

        private void RecognizeRunStep(float leftAnkleRise, float rightAnkleRise, float torso, float now)
        {
            float leftKneeLift = (baseline.LeftKnee.y - smoothed.LeftKnee.y) / torso;
            float rightKneeLift = (baseline.RightKnee.y - smoothed.RightKnee.y) / torso;
            float leftAngle = KneeAngle(smoothed.LeftHip, smoothed.LeftKnee, smoothed.LeftAnkle);
            float rightAngle = KneeAngle(smoothed.RightHip, smoothed.RightKnee, smoothed.RightAnkle);
            float stepKneeLift = Mathf.Lerp(MaximumStepKneeLift, MinimumStepKneeLift, runSensitivity);
            float stepAnkleLift = Mathf.Lerp(MaximumStepAnkleLift, MinimumStepAnkleLift, runSensitivity);
            float stepKneeAngle = Mathf.Lerp(MinimumStepKneeAngle, MaximumStepKneeAngle, runSensitivity);
            float stepSideDifference = Mathf.Lerp(
                MaximumStepSideDifference,
                MinimumStepSideDifference,
                runSensitivity);

            bool leftRaised = leftKneeLift > stepKneeLift &&
                              leftAnkleRise > stepAnkleLift &&
                              (leftAngle < stepKneeAngle || leftKneeLift > stepKneeLift * 1.25f) &&
                              leftKneeLift > rightKneeLift + stepSideDifference;
            bool rightRaised = rightKneeLift > stepKneeLift &&
                               rightAnkleRise > stepAnkleLift &&
                               (rightAngle < stepKneeAngle || rightKneeLift > stepKneeLift * 1.25f) &&
                               rightKneeLift > leftKneeLift + stepSideDifference;

            int raisedSide = leftRaised == rightRaised ? 0 : leftRaised ? -1 : 1;
            if (raisedSide == 0)
            {
                raisedLegState = 0;
                return;
            }

            if (raisedSide == raisedLegState)
            {
                return;
            }

            raisedLegState = raisedSide;
            float sinceLastStep = now - lastStepAt;
            bool firstOrRestarted = lastStepSide == 0 || sinceLastStep > StepCadenceMaximum;
            bool alternating = raisedSide != lastStepSide &&
                               sinceLastStep >= StepCadenceMinimum &&
                               sinceLastStep <= StepCadenceMaximum;

            if (firstOrRestarted)
            {
                runUntil = Mathf.Max(runUntil, now + FirstStepRunGrace);
                lastStepSide = raisedSide;
                lastStepAt = now;
                lastGesture = "Run";
            }
            else if (alternating)
            {
                runUntil = Mathf.Max(runUntil, now + AlternatingRunGrace);
                lastStepSide = raisedSide;
                lastStepAt = now;
                lastGesture = "Run";
            }
        }

        private float KneeAngle(Vector2 hip, Vector2 knee, Vector2 ankle)
        {
            Vector2 correctedHip = CorrectAspect(hip);
            Vector2 correctedKnee = CorrectAspect(knee);
            Vector2 correctedAnkle = CorrectAspect(ankle);
            return Vector2.Angle(correctedHip - correctedKnee, correctedAnkle - correctedKnee);
        }

        private Vector2 CorrectAspect(Vector2 point)
        {
            return new Vector2(point.x * smoothed.Aspect, point.y);
        }

        private void ClearTransientState()
        {
            jumpPoseActive = false;
            jumpArmed = false;
            jumpCandidateAt = landingCandidateAt = crouchCandidateAt = standCandidateAt = -1f;
            pendingJumpUntil = lastJumpAt = lastLandingAt = -100f;
            crouchHeld = false;
            crouchMaintainsRun = false;
            candidateBodyLane = -1;
            candidateBodyLaneStartedAt = 0f;
            raisedLegState = 0;
            lastStepSide = 0;
            lastStepAt = -100f;
            runUntil = -100f;
            pendingJump = false;
        }
    }
}
