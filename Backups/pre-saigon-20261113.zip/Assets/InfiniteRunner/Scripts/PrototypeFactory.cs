using System;
using System.Collections.Generic;
using UnityEngine;

namespace InfiniteRunner
{
    public sealed class PrototypePalette : IDisposable
    {
        private readonly List<Material> materials = new List<Material>();
        private StreetObstacleLibrary streetObjects;

        public StreetObstacleLibrary StreetObjects => streetObjects ?? (streetObjects = new StreetObstacleLibrary(this));

        public Material Road { get; }
        public Material RoadEdge { get; }
        public Material LaneLine { get; }
        public Material BlockObstacle { get; }
        public Material JumpObstacle { get; }
        public Material SlideObstacle { get; }
        public Material Coin { get; }
        public Material PlayerBody { get; }
        public Material PlayerAccent { get; }
        public Material PlayerDark { get; }
        public Material BuildingA { get; }
        public Material BuildingB { get; }
        public Material Window { get; }
        public Material Limestone { get; }
        public Material Steel { get; }
        public Material Brick { get; }
        public Material Foliage { get; }
        public Material LeafLight { get; }
        public Material Bark { get; }
        public Material SignGreen { get; }
        public Material FlagBlue { get; }
        public Material FlagRed { get; }
        public Material TrainSilver { get; }
        public Material Cloud { get; }
        public Material Sky { get; }
        public Material TaxiPaint { get; }
        public Material CarPaint { get; }
        public Material VanPaint { get; }
        public Material VehicleGlass { get; }
        public Material Rubber { get; }
        public Material Chrome { get; }
        public Material Headlight { get; }
        public Material Taillight { get; }

        public PrototypePalette()
        {
            Road = Create(new Color(0.43f, 0.49f, 0.53f), 0.15f);
            RoadEdge = Create(new Color(0.88f, 0.85f, 0.76f), 0.15f);
            LaneLine = Create(new Color(1f, 0.98f, 0.88f), 0.15f);
            BlockObstacle = Create(new Color(0.94f, 0.22f, 0.25f), 0.3f);
            JumpObstacle = Create(new Color(1f, 0.59f, 0.06f), 0.25f);
            SlideObstacle = Create(new Color(0.53f, 0.25f, 0.81f), 0.35f);
            Coin = Create(new Color(1f, 0.76f, 0.06f), 0.6f, true);
            PlayerBody = Create(new Color(0.06f, 0.47f, 0.73f), 0.35f);
            PlayerAccent = Create(new Color(1f, 0.36f, 0.19f), 0.3f);
            PlayerDark = Create(new Color(0.11f, 0.2f, 0.29f), 0.15f);
            BuildingA = Create(new Color(0.39f, 0.64f, 0.73f), 0.45f);
            BuildingB = Create(new Color(0.67f, 0.79f, 0.81f), 0.45f);
            Window = Create(new Color(0.27f, 0.5f, 0.6f), 0.6f);
            Limestone = Create(new Color(0.94f, 0.87f, 0.7f), 0.15f);
            Steel = Create(new Color(0.22f, 0.31f, 0.34f), 0.3f);
            Brick = Create(new Color(0.7f, 0.39f, 0.28f), 0.1f);
            Foliage = Create(new Color(0.24f, 0.57f, 0.28f), 0.1f);
            LeafLight = Create(new Color(0.48f, 0.73f, 0.31f), 0.1f);
            Bark = Create(new Color(0.45f, 0.31f, 0.2f), 0.1f);
            SignGreen = Create(new Color(0.05f, 0.34f, 0.27f), 0.1f);
            FlagBlue = Create(new Color(0.3f, 0.73f, 0.9f), 0.2f);
            FlagRed = Create(new Color(0.91f, 0.22f, 0.24f), 0.15f);
            TrainSilver = Create(new Color(0.82f, 0.86f, 0.86f), 0.5f);
            Cloud = Create(new Color(1f, 0.99f, 0.94f), 0f);
            Cloud.SetFloat("_Unlit", 1f);
            TaxiPaint = Create(new Color(1f, 0.72f, 0.06f), 0.7f);
            CarPaint = Create(new Color(0.1f, 0.36f, 0.63f), 0.8f);
            VanPaint = Create(new Color(0.95f, 0.96f, 0.91f), 0.6f);
            VehicleGlass = Create(new Color(0.07f, 0.18f, 0.25f), 0.9f);
            Rubber = Create(new Color(0.045f, 0.055f, 0.065f), 0.05f);
            Chrome = Create(new Color(0.71f, 0.76f, 0.79f), 0.85f);
            Headlight = Create(new Color(1f, 0.95f, 0.73f), 0.65f, true);
            Taillight = Create(new Color(0.95f, 0.065f, 0.04f), 0.6f, true);
            Sky = new Material(Resources.Load<Shader>("ChicagoSky")) { name = "Chicago summer sky" };
            materials.Add(Sky);
        }

        private Material Create(Color color, float smoothness, bool emission = false)
        {
            Shader shader = Resources.Load<Shader>("PrototypeLit");
            if (shader == null)
            {
                shader = Shader.Find("InfiniteRunner/PrototypeLit");
            }

            if (shader == null)
            {
                shader = Shader.Find("Standard");
            }

            Material material = new Material(shader)
            {
                name = $"Prototype {color}",
                color = color,
                enableInstancing = true
            };

            if (material.HasProperty("_BaseColor"))
            {
                material.SetColor("_BaseColor", color);
            }

            if (material.HasProperty("_Smoothness"))
            {
                material.SetFloat("_Smoothness", smoothness);
            }

            if (emission && material.HasProperty("_EmissionColor"))
            {
                material.EnableKeyword("_EMISSION");
                material.SetColor("_EmissionColor", color * 0.18f);
            }

            materials.Add(material);
            return material;
        }

        public void Dispose()
        {
            streetObjects?.Dispose();
            streetObjects = null;
            foreach (Material material in materials)
            {
                if (material != null)
                {
                    if (Application.isPlaying) UnityEngine.Object.Destroy(material);
                    else UnityEngine.Object.DestroyImmediate(material);
                }
            }

            materials.Clear();
        }
    }

    public static class PrototypeFactory
    {
        public static GameObject CreatePrimitive(
            string objectName,
            PrimitiveType primitiveType,
            Transform parent,
            Vector3 localPosition,
            Vector3 localScale,
            Material material,
            bool keepCollider,
            Quaternion? localRotation = null)
        {
            GameObject instance = GameObject.CreatePrimitive(primitiveType);
            instance.name = objectName;
            instance.transform.SetParent(parent, false);
            instance.transform.localPosition = localPosition;
            instance.transform.localRotation = localRotation ?? Quaternion.identity;
            instance.transform.localScale = localScale;

            Renderer renderer = instance.GetComponent<Renderer>();
            if (renderer != null)
            {
                renderer.sharedMaterial = material;
            }

            if (!keepCollider)
            {
                Collider collider = instance.GetComponent<Collider>();
                if (collider != null)
                {
                    collider.enabled = false;
                    if (Application.isPlaying) UnityEngine.Object.Destroy(collider);
                    else UnityEngine.Object.DestroyImmediate(collider);
                }
            }

            return instance;
        }
    }

}
