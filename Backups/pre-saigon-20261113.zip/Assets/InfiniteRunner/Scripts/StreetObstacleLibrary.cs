using System;
using System.Collections.Generic;
using UnityEngine;

namespace InfiniteRunner
{
    /// <summary>Builds each street prop once. Pooled instances share its meshes and materials.</summary>
    public sealed class StreetObstacleLibrary : IDisposable
    {
        public const float VehicleRearZ = -0.575f;
        public const float VehicleLength = 4.3f;
        public const float VehicleCenterZ = VehicleRearZ + VehicleLength * 0.5f;

        private readonly PrototypePalette palette;
        private readonly GameObject templates;
        private readonly Dictionary<int, GameObject> models = new Dictionary<int, GameObject>();

        public StreetObstacleLibrary(PrototypePalette palette)
        {
            this.palette = palette;
            templates = new GameObject("Shared street object meshes");
            templates.SetActive(false);
        }

        public GameObject Create(Transform parent, ObstacleKind kind, int variant)
        {
            int key = kind == ObstacleKind.Block ? variant % 3 : (int)kind + 2;
            if (!models.TryGetValue(key, out GameObject template))
            {
                template = new GameObject(key < 3 ? new[] { "Chicago taxi", "Blue sedan", "Delivery van" }[key] : key == 3 ? "Roadwork barricade" : key == 4 ? "Construction scaffold" : "Train roof ventilation unit");
                template.transform.SetParent(templates.transform, false);
                var builder = new SceneryMeshBuilder(template.transform);
                if (key < 3) BuildVehicle(builder, key);
                else if (key == 3) BuildBarricade(builder);
                else if (key == 4) BuildScaffold(builder);
                else BuildRoofVent(builder);
                builder.Finish();
                models.Add(key, template);
            }

            var instance = new GameObject(template.name);
            instance.transform.SetParent(parent, false);
            // Do not clone the mesh owner: only the template owns the shared mesh lifetime.
            foreach (MeshFilter source in template.GetComponentsInChildren<MeshFilter>(true))
            {
                var part = new GameObject(source.name);
                part.transform.SetParent(instance.transform, false);
                part.AddComponent<MeshFilter>().sharedMesh = source.sharedMesh;
                part.AddComponent<MeshRenderer>().sharedMaterial = source.GetComponent<MeshRenderer>().sharedMaterial;
            }
            if (key == 0)
                Label(instance.transform, "TAXI", new Vector3(0, 1.96f, 1.10f), 0.042f, palette.Rubber.color);
            if (key == 2)
                Label(instance.transform, "CHICAGO\nDELIVERY", new Vector3(0, 1.59f, -0.555f), 0.055f, new Color(0.05f, 0.31f, 0.46f));
            return instance;
        }

        private void BuildVehicle(SceneryMeshBuilder b, int variant)
        {
            PrototypePalette p = palette;
            Material paint = variant == 0 ? p.TaxiPaint : variant == 1 ? p.CarPaint : p.VanPaint;
            float center = VehicleCenterZ;
            b.Box("Chassis", new Vector3(0, 0.36f, center), new Vector3(1.68f, 0.25f, 4.15f), p.Rubber);
            b.TaperedBox(new Vector3(0, 0.40f, center), new Vector2(1.68f, 4.05f), new Vector3(0, 0.94f, center), new Vector2(1.85f, VehicleLength), paint);
            b.TaperedBox(new Vector3(0, 0.94f, center), new Vector2(1.85f, VehicleLength), new Vector3(0, 1.06f, center), new Vector2(1.73f, 4.05f), paint);

            for (int side = -1; side <= 1; side += 2)
            {
                foreach (float wheelZ in new[] { 0.22f, 2.91f })
                {
                    Quaternion axle = Quaternion.Euler(0, 0, 90);
                    b.Cylinder(new Vector3(side * 0.86f, 0.34f, wheelZ), 0.34f, 0.22f, p.Rubber, axle);
                    b.Cylinder(new Vector3(side * 0.977f, 0.34f, wheelZ), 0.215f, 0.025f, p.Chrome, axle);
                    b.Cylinder(new Vector3(side * 0.995f, 0.34f, wheelZ), 0.09f, 0.03f, p.Steel, axle);
                    for (int spoke = 0; spoke < 5; spoke++)
                    {
                        float angle = spoke * Mathf.PI * 2 / 5;
                        b.Beam(new Vector3(side, 0.34f, wheelZ), new Vector3(side, 0.34f + Mathf.Cos(angle) * 0.19f, wheelZ + Mathf.Sin(angle) * 0.19f), 0.035f, p.TrainSilver);
                    }
                }
                b.Box("Lower sill", new Vector3(side * 0.9f, 0.39f, 1.52f), new Vector3(0.08f, 0.12f, 1.65f), paint);
                b.Box("Mirror arm", new Vector3(side * 0.9f, 1.17f, 2.53f), new Vector3(0.2f, 0.06f, 0.07f), p.Rubber);
                b.Box("Side mirror", new Vector3(side * 1.025f, 1.19f, 2.5f), new Vector3(0.14f, 0.16f, 0.27f), paint);
                b.Box("Mirror glass", new Vector3(side * 1.025f, 1.19f, 2.36f), new Vector3(0.12f, 0.13f, 0.015f), p.Chrome);
            }

            if (variant == 2) BuildVanCabin(b, paint);
            else BuildCarCabin(b, paint, variant == 0);

            foreach (float endZ in new[] { VehicleRearZ - 0.025f, VehicleRearZ + VehicleLength + 0.025f })
            {
                bool rear = endZ < 0;
                b.Box("Bumper", new Vector3(0, 0.48f, endZ), new Vector3(1.75f, 0.18f, 0.09f), p.Rubber);
                b.Box("Bumper trim", new Vector3(0, 0.62f, endZ), new Vector3(1.64f, 0.06f, 0.045f), p.Chrome);
                b.Box("Illinois plate", new Vector3(0, 0.75f, endZ + (rear ? -0.03f : 0.03f)), new Vector3(0.43f, 0.18f, 0.02f), p.LaneLine);
                b.Box("Plate blue band", new Vector3(0, 0.81f, endZ + (rear ? -0.044f : 0.044f)), new Vector3(0.4f, 0.035f, 0.015f), p.FlagBlue);
                for (int side = -1; side <= 1; side += 2)
                {
                    b.Box("Light housing", new Vector3(side * 0.64f, 0.88f, endZ), new Vector3(0.40f, 0.21f, 0.06f), p.Rubber);
                    b.Box(rear ? "Tail lamp" : "Headlamp", new Vector3(side * 0.64f, 0.89f, endZ + (rear ? -0.04f : 0.04f)), new Vector3(0.34f, 0.16f, 0.025f), rear ? p.Taillight : p.Headlight);
                    b.Box("Indicator", new Vector3(side * 0.79f, 0.89f, endZ + (rear ? -0.055f : 0.055f)), new Vector3(0.055f, 0.13f, 0.02f), p.JumpObstacle);
                }
                if (!rear)
                {
                    b.Box("Grille", new Vector3(0, 0.91f, endZ), new Vector3(0.69f, 0.16f, 0.05f), p.Rubber);
                    for (int bar = 0; bar < 3; bar++)
                        b.Box("Grille trim", new Vector3(0, 0.86f + bar * 0.05f, endZ + 0.03f), new Vector3(0.62f, 0.017f, 0.015f), p.Chrome);
                }
            }
        }

        private void BuildCarCabin(SceneryMeshBuilder b, Material paint, bool taxi)
        {
            PrototypePalette p = palette;
            b.TaperedBox(new Vector3(0, 1.055f, 1.45f), new Vector2(1.60f, 2.8f), new Vector3(0, 1.76f, 1.35f), new Vector2(1.34f, 1.65f), p.VehicleGlass);
            b.Box("Roof", new Vector3(0, 1.78f, 1.35f), new Vector3(1.4f, 0.10f, 1.75f), paint);
            for (int side = -1; side <= 1; side += 2)
            {
                b.Beam(new Vector3(side * 0.8f, 1.07f, 0.05f), new Vector3(side * 0.67f, 1.76f, 0.525f), 0.085f, paint);
                b.Beam(new Vector3(side * 0.8f, 1.07f, 2.85f), new Vector3(side * 0.67f, 1.76f, 2.175f), 0.085f, paint);
                b.Beam(new Vector3(side * 0.8f, 1.07f, 1.35f), new Vector3(side * 0.67f, 1.76f, 1.35f), 0.07f, p.Rubber);
                b.Box("Door seam", new Vector3(side * 0.93f, 0.77f, 1.34f), new Vector3(0.008f, 0.40f, 0.018f), p.VehicleGlass);
                foreach (float doorZ in new[] { 0.8f, 2.1f })
                    b.Box("Door handle", new Vector3(side * 0.93f, 0.94f, doorZ), new Vector3(0.035f, 0.045f, 0.22f), p.Chrome);
                if (taxi)
                {
                    b.Box("Taxi checker stripe", new Vector3(side * 0.93f, 0.78f, 1.55f), new Vector3(0.025f, 0.16f, 2.1f), p.LaneLine);
                    for (int check = 0; check < 14; check++)
                        b.Box("Taxi checker", new Vector3(side * 0.95f, 0.74f + check % 2 * 0.08f, 0.55f + check * 0.15f), new Vector3(0.015f, 0.08f, 0.14f), p.Rubber);
                }
            }
            b.Box("Rear glass reflection", new Vector3(-0.2f, 1.48f, 0.313f), new Vector3(0.68f, 0.045f, 0.025f), p.BuildingB, Quaternion.Euler(-35, 0, 0));
            if (taxi)
            {
                b.Box("Taxi sign base", new Vector3(0, 1.85f, 1.28f), new Vector3(0.72f, 0.05f, 0.4f), p.Rubber);
                b.TaperedBox(new Vector3(0, 1.88f, 1.28f), new Vector2(0.67f, 0.34f), new Vector3(0, 2.05f, 1.28f), new Vector2(0.59f, 0.26f), p.Headlight);
            }
        }

        private void BuildVanCabin(SceneryMeshBuilder b, Material paint)
        {
            PrototypePalette p = palette;
            b.TaperedBox(new Vector3(0, 1.02f, 0.85f), new Vector2(1.78f, 2.76f), new Vector3(0, 2.33f, 0.88f), new Vector2(1.66f, 2.63f), paint);
            b.TaperedBox(new Vector3(0, 1.04f, 2.64f), new Vector2(1.68f, 1.2f), new Vector3(0, 2.12f, 2.38f), new Vector2(1.54f, 0.8f), p.VehicleGlass);
            b.Box("Cab roof", new Vector3(0, 2.16f, 2.35f), new Vector3(1.63f, 0.10f, 0.96f), paint);
            b.Box("Rear door divider", new Vector3(0, 1.62f, -0.538f), new Vector3(0.023f, 1.28f, 0.02f), p.Chrome);
            for (int side = -1; side <= 1; side += 2)
            {
                b.Box("Delivery blue stripe", new Vector3(side * 0.89f, 1.21f, 0.95f), new Vector3(0.018f, 0.21f, 2.52f), p.CarPaint);
                b.Box("Cargo door handle", new Vector3(side * 0.12f, 1.21f, -0.55f), new Vector3(0.06f, 0.19f, 0.04f), p.Rubber);
                b.Box("Van rear lamp", new Vector3(side * 0.79f, 1.27f, -0.53f), new Vector3(0.12f, 0.40f, 0.05f), p.Taillight);
                b.Beam(new Vector3(side * 0.84f, 1.05f, 3.24f), new Vector3(side * 0.77f, 2.12f, 2.78f), 0.09f, paint);
                b.Box("Cab door handle", new Vector3(side * 0.93f, 0.96f, 2.36f), new Vector3(0.035f, 0.055f, 0.20f), p.Chrome);
            }
        }

        private void BuildBarricade(SceneryMeshBuilder b)
        {
            PrototypePalette p = palette;
            b.TaperedBox(new Vector3(0, 0.06f, 0), new Vector2(2.05f, 0.7f), new Vector3(0, 0.48f, 0), new Vector2(2.0f, 0.32f), p.JumpObstacle);
            b.Box("Barricade upper panel", new Vector3(0, 0.65f, 0), new Vector3(2.0f, 0.34f, 0.32f), p.JumpObstacle);
            b.Box("Reflective white strip", new Vector3(0, 0.63f, -0.167f), new Vector3(1.96f, 0.24f, 0.016f), p.LaneLine);
            for (int stripe = -3; stripe <= 3; stripe++)
                b.Box("Orange safety stripe", new Vector3(stripe * 0.28f, 0.63f, -0.181f), new Vector3(0.115f, 0.27f, 0.012f), p.JumpObstacle, Quaternion.Euler(0, 0, -28));
            foreach (float x in new[] { -0.72f, 0.72f })
            {
                b.Box("Barricade rubber foot", new Vector3(x, 0.045f, 0), new Vector3(0.42f, 0.09f, 0.7f), p.Rubber);
                b.Box("Reflector", new Vector3(x, 0.84f, 0), new Vector3(0.16f, 0.04f, 0.13f), p.Headlight);
            }
        }

        private void BuildScaffold(SceneryMeshBuilder b)
        {
            PrototypePalette p = palette;
            for (int side = -1; side <= 1; side += 2)
            {
                float x = side * 1.10f;
                foreach (float z in new[] { -0.44f, 0.44f })
                {
                    b.Cylinder(new Vector3(x, 0.97f, z), 0.065f, 1.94f, p.Chrome);
                    b.Box("Scaffold baseplate", new Vector3(x, 0.045f, z), new Vector3(0.30f, 0.09f, 0.28f), p.Steel);
                }
                b.Beam(new Vector3(x, 0.3f, -0.44f), new Vector3(x, 1.52f, 0.44f), 0.045f, p.Chrome);
                b.Beam(new Vector3(x, 0.3f, 0.44f), new Vector3(x, 1.52f, -0.44f), 0.045f, p.Chrome);
            }
            b.Box("Low overhead beam", new Vector3(0, 1.61f, 0), new Vector3(2.1f, 0.36f, 1.05f), p.JumpObstacle);
            b.Box("Reflective clearance band", new Vector3(0, 1.62f, -0.54f), new Vector3(2.08f, 0.27f, 0.025f), p.LaneLine);
            for (int stripe = -3; stripe <= 3; stripe++)
                b.Box("Clearance warning stripe", new Vector3(stripe * 0.3f, 1.62f, -0.56f), new Vector3(0.13f, 0.28f, 0.015f), p.JumpObstacle, Quaternion.Euler(0, 0, -30));
            for (int plank = 0; plank < 4; plank++)
                b.Box("Scaffold timber deck", new Vector3(0, 1.86f, -0.39f + plank * 0.26f), new Vector3(2.3f, 0.14f, 0.23f), p.Bark);
            b.Box("Clearance sign", new Vector3(0, 1.65f, -0.59f), new Vector3(0.37f, 0.30f, 0.035f), p.SignGreen);
            b.Beam(new Vector3(-0.12f, 1.71f, -0.615f), new Vector3(0, 1.58f, -0.615f), 0.04f, p.LaneLine);
            b.Beam(new Vector3(0.12f, 1.71f, -0.615f), new Vector3(0, 1.58f, -0.615f), 0.04f, p.LaneLine);
        }

        private void BuildRoofVent(SceneryMeshBuilder b)
        {
            PrototypePalette p = palette;
            b.Box("Roof vent mounting feet", new Vector3(0, 0.08f, 0), new Vector3(2.05f, 0.16f, 0.7f), p.Rubber);
            b.Box("Vent housing", new Vector3(0, 0.44f, 0), new Vector3(1.94f, 0.62f, 0.64f), p.TrainSilver);
            b.Box("Vent cap", new Vector3(0, 0.805f, 0), new Vector3(2.02f, 0.11f, 0.68f), p.Chrome);
            b.Box("Louver opening", new Vector3(0, 0.43f, -0.328f), new Vector3(1.72f, 0.40f, 0.018f), p.Rubber);
            for (int slat = 0; slat < 5; slat++)
                b.Box("Vent louver", new Vector3(0, 0.28f + slat * 0.075f, -0.345f), new Vector3(1.72f, 0.026f, 0.028f), p.Chrome);
            foreach (float x in new[] { -0.51f, 0.51f })
            {
                b.Cylinder(new Vector3(x, 0.87f, 0), 0.245f, 0.018f, p.Steel);
                for (int blade = 0; blade < 4; blade++)
                    b.Box("Fan grille", new Vector3(x, 0.885f, 0), new Vector3(0.46f, 0.012f, 0.024f), p.TrainSilver, Quaternion.Euler(0, blade * 45, 0));
            }
            b.Box("Vent warning edge", new Vector3(0, 0.77f, -0.35f), new Vector3(1.96f, 0.09f, 0.025f), p.JumpObstacle);
        }

        private static void Label(Transform parent, string content, Vector3 position, float size, Color color)
        {
            var item = new GameObject(content);
            item.transform.SetParent(parent, false);
            item.transform.localPosition = position;
            var text = item.AddComponent<TextMesh>();
            text.text = content;
            text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.fontSize = 48;
            text.characterSize = size;
            text.anchor = TextAnchor.MiddleCenter;
            text.alignment = TextAlignment.Center;
            text.color = color;
            text.GetComponent<MeshRenderer>().sharedMaterial = text.font.material;
        }

        public void Dispose()
        {
            if (templates != null)
            {
                if (Application.isPlaying) UnityEngine.Object.Destroy(templates);
                else UnityEngine.Object.DestroyImmediate(templates);
            }
            models.Clear();
        }
    }
}
