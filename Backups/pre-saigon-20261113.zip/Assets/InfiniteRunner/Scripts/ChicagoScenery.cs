using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace InfiniteRunner
{
    /// <summary>Reusable, collider-free Chicago streets and a distant landmark skyline.</summary>
    public static class ChicagoScenery
    {
        public static void BuildStreet(Transform parent, int block, float length, float laneWidth, PrototypePalette p)
        {
            var b = new SceneryMeshBuilder(parent);
            b.Box("Sidewalks", new Vector3(0, -0.38f, length / 2), new Vector3(65, 0.25f, length), p.RoadEdge);
            for (int side = -1; side <= 1; side += 2)
            {
                b.Box("Limestone sidewalk", new Vector3(side * 6.4f, -0.02f, length / 2), new Vector3(3.2f, 0.16f, length), p.RoadEdge);
                b.Box("Curb", new Vector3(side * 4.85f, 0.08f, length / 2), new Vector3(0.2f, 0.22f, length), p.LaneLine);
                for (int dash = 0; dash < 6; dash++)
                    b.Box("Painted lane marking", new Vector3(side * laneWidth / 2, 0.015f, 2 + dash * 5), new Vector3(0.11f, 0.025f, 2.4f), p.LaneLine);
                for (int seam = 0; seam < 6; seam++)
                    b.Box("Paving joint", new Vector3(side * 6.5f, 0.066f, seam * 5), new Vector3(2.9f, 0.008f, 0.025f), p.Limestone);
                Tree(b, side * 6.4f, 6, p);
                Tree(b, side * 6.4f, 22, p);
                Lamp(b, side * 5.25f, 13, p);
                Flag(b, side * 6.85f, 14, p);
                StreetSign(parent, b, side * 5.45f, 25, side == -1 ? "W WACKER DR" : "N MICHIGAN AV", p);
            }

            var random = new System.Random(1709 + block * 97);
            for (int side = -1; side <= 1; side += 2)
            for (int index = 0; index < 3; index++)
            {
                float z = 4.7f + index * 10;
                float height = 8 + (float)random.NextDouble() * 9;
                float x = side * (side < 0 ? 15.5f : 12.2f);
                if (index == 1 && block % 3 == 1)
                {
                    x += side * 10;
                    height += 10;
                }
                bool masonry = (index + block + side) % 3 != 0;
                Building(b, x, z, 7, height, 8.7f, masonry ? (index % 2 == 0 ? p.Limestone : p.Brick) : p.BuildingA, masonry, p);
            }

            // The elevated line sits beside the course, leaving every running lane clear.
            for (int rail = 0; rail < 2; rail++)
            {
                float x = -9.1f - rail * 2.1f;
                b.Box("L longitudinal girder", new Vector3(x, 5.4f, length / 2), new Vector3(0.22f, 0.7f, length), p.Steel);
                b.Box("L rail", new Vector3(x, 5.91f, length / 2), new Vector3(0.12f, 0.12f, length), p.TrainSilver);
                for (int pier = 0; pier < 2; pier++)
                    b.Box("L steel column", new Vector3(x, 2.6f, 3 + pier * 15), new Vector3(0.3f, 5.2f, 0.32f), p.Steel);
            }
            for (int tie = 0; tie < 15; tie++)
                b.Box("L cross tie", new Vector3(-10.15f, 5.72f, tie * 2), new Vector3(2.9f, 0.16f, 0.3f), p.Bark);
            for (int pier = 0; pier < 2; pier++)
                b.Beam(new Vector3(-9.1f, 0.3f, 3 + pier * 15), new Vector3(-11.2f, 5.3f, 3 + pier * 15), 0.13f, p.Steel);
            if (block % 3 == 1) Train(b, -10.15f, 15, p);
            b.Finish();
        }

        private static void Building(SceneryMeshBuilder b, float x, float z, float width, float height, float depth, Material wall, bool masonry, PrototypePalette p)
        {
            b.Box("Loop tower", new Vector3(x, height / 2, z), new Vector3(width, height, depth), wall);
            b.Box("Cornice", new Vector3(x, height, z), new Vector3(width + 0.35f, 0.45f, depth + 0.3f), masonry ? p.Limestone : p.TrainSilver);
            b.Box("Street level stone", new Vector3(x, 1.3f, z), new Vector3(width + 0.15f, 2.6f, depth + 0.12f), p.Limestone);
            float faceX = x - Mathf.Sign(x) * (width / 2 + 0.025f);
            for (float y = 3.8f; y < height - 0.8f; y += masonry ? 2.6f : 2.2f)
            {
                for (int col = 0; col < 3; col++)
                {
                    b.Box("Avenue windows", new Vector3(faceX, y, z - depth * 0.31f + col * depth * 0.31f), new Vector3(0.04f, 1.35f, masonry ? 1.25f : 2.3f), p.Window);
                    b.Box("Front windows", new Vector3(x - width * 0.31f + col * width * 0.31f, y, z - depth / 2 - 0.025f), new Vector3(masonry ? 1.2f : 1.8f, 1.35f, 0.04f), p.Window);
                }
            }
            for (int col = 0; col < 3; col++)
                b.Box("Shopfront", new Vector3(faceX, 1.15f, z - 2.6f + col * 2.6f), new Vector3(0.06f, 1.9f, 1.7f), p.Window);
            b.Box("Store awning", new Vector3(faceX - Mathf.Sign(x) * 0.4f, 2.4f, z), new Vector3(1, 0.18f, depth * 0.75f), p.SignGreen);
        }

        private static void Tree(SceneryMeshBuilder b, float x, float z, PrototypePalette p)
        {
            b.Box("Tree planter", new Vector3(x, 0.23f, z), new Vector3(1.45f, 0.35f, 1.45f), p.Limestone);
            b.Box("Tree trunk", new Vector3(x, 1.25f, z), new Vector3(0.22f, 2.3f, 0.22f), p.Bark);
            b.Crown(new Vector3(x, 2.8f, z), new Vector3(1.25f, 1.6f, 1.2f), p.Foliage);
            b.Crown(new Vector3(x + 0.35f, 3.4f, z), new Vector3(1.05f, 1.25f, 1.1f), p.LeafLight);
        }

        private static void Lamp(SceneryMeshBuilder b, float x, float z, PrototypePalette p)
        {
            b.Box("Lamp base", new Vector3(x, 0.25f, z), new Vector3(0.4f, 0.5f, 0.4f), p.Steel);
            b.Box("Street lamp", new Vector3(x, 2.7f, z), new Vector3(0.13f, 5.4f, 0.13f), p.Steel);
            b.Box("Lamp arm", new Vector3(x - Mathf.Sign(x) * 0.45f, 5.4f, z), new Vector3(1, 0.1f, 0.1f), p.Steel);
            b.Box("Lamp shade", new Vector3(x - Mathf.Sign(x) * 0.9f, 5.32f, z), new Vector3(0.55f, 0.16f, 0.35f), p.Limestone);
        }

        private static void Flag(SceneryMeshBuilder b, float x, float z, PrototypePalette p)
        {
            b.Box("Flagpole", new Vector3(x, 2.7f, z), new Vector3(0.07f, 5.4f, 0.07f), p.TrainSilver);
            float centerX = x + 0.77f;
            b.Box("Chicago flag white field", new Vector3(centerX, 4.62f, z), new Vector3(1.5f, 0.9f, 0.045f), p.LaneLine);
            foreach (float stripeY in new[] { 4.36f, 4.88f })
                b.Box("Chicago sky blue stripe", new Vector3(centerX, stripeY, z - 0.03f), new Vector3(1.5f, 0.16f, 0.015f), p.FlagBlue);
            for (int star = 0; star < 4; star++)
                b.Star(new Vector3(x + 0.27f + star * 0.33f, 4.62f, z - 0.04f), 0.12f, p.FlagRed);
        }

        private static void StreetSign(Transform parent, SceneryMeshBuilder b, float x, float z, string label, PrototypePalette p)
        {
            b.Box("Signpost", new Vector3(x, 1.9f, z), new Vector3(0.09f, 3.8f, 0.09f), p.Steel);
            b.Box("Street sign rim", new Vector3(x, 3.8f, z), new Vector3(2.75f, 0.57f, 0.11f), p.LaneLine);
            b.Box("Chicago street sign", new Vector3(x, 3.8f, z - 0.065f), new Vector3(2.63f, 0.45f, 0.04f), p.SignGreen);
            var sign = new GameObject(label);
            sign.transform.SetParent(parent, false);
            sign.transform.localPosition = new Vector3(x, 3.8f, z - 0.095f);
            var text = sign.AddComponent<TextMesh>();
            text.text = label;
            text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.fontSize = 48;
            text.characterSize = 0.068f;
            text.anchor = TextAnchor.MiddleCenter;
            text.alignment = TextAlignment.Center;
            text.color = Color.white;
            text.GetComponent<MeshRenderer>().sharedMaterial = text.font.material;
        }

        private static void Train(SceneryMeshBuilder b, float x, float z, PrototypePalette p)
        {
            for (int car = 0; car < 2; car++)
            {
                float carZ = z + car * 9;
                b.Box("L silver carriage", new Vector3(x, 7.1f, carZ), new Vector3(2.2f, 2.3f, 8.2f), p.TrainSilver);
                b.Box("L blue stripe", new Vector3(x + 1.12f, 6.7f, carZ), new Vector3(0.04f, 0.22f, 8), p.FlagBlue);
                for (int window = 0; window < 5; window++)
                    b.Box("L carriage window", new Vector3(x + 1.12f, 7.5f, carZ - 3 + window * 1.5f), new Vector3(0.04f, 0.8f, 1.05f), p.Window);
                b.Box("L windshield", new Vector3(x, 7.5f, carZ - 4.12f), new Vector3(1.7f, 0.8f, 0.04f), p.Window);
            }
        }

        public static void CreateSkyline(Transform parent, Transform runner, PrototypePalette p)
        {
            var root = new GameObject("Chicago landmark skyline");
            root.transform.SetParent(parent, false);
            root.transform.localScale = new Vector3(1, 0.72f, 1);
            root.AddComponent<ChicagoSkylineFollow>().Configure(runner);
            var b = new SceneryMeshBuilder(root.transform);
            // A distant ground apron keeps the far end of the pooled avenue in the haze.
            b.Box("Distant city ground", new Vector3(0, -0.7f, 260), new Vector3(650, 0.5f, 580), p.RoadEdge);
            b.Box("Avenue into the horizon", new Vector3(0, -0.31f, 330), new Vector3(9.6f, 0.1f, 300), p.Road);
            // Bundled setbacks and twin antennas evoke Willis Tower.
            for (int col = 0; col < 3; col++)
            for (int row = 0; row < 2; row++)
            {
                float height = 63 + (col == 1 ? 37 : col == 0 ? 22 : 0) - row * 8;
                float x = -48 + col * 7;
                float z = 240 + row * 7;
                b.Box("Willis bundled tower", new Vector3(x, height / 2, z), new Vector3(7, height, 7), p.Steel);
                for (int rib = 0; rib < 3; rib++)
                    b.Box("Willis silver ribs", new Vector3(x - 2 + rib * 2, height / 2, z - 3.55f), new Vector3(0.17f, height, 0.08f), p.BuildingB);
            }
            for (int antenna = 0; antenna < 2; antenna++)
                b.Box("Willis antenna", new Vector3(-43 + antenna * 4, 107, 240), new Vector3(0.48f, 18, 0.48f), p.TrainSilver);

            // Hancock's dark silhouette and large diagonal braces.
            b.Box("Hancock tower", new Vector3(66, 42, 295), new Vector3(20, 84, 14), p.Steel);
            for (int floor = 0; floor < 4; floor++)
            {
                float y = floor * 20 + 2;
                b.Beam(new Vector3(56, y, 287.8f), new Vector3(76, y + 20, 287.8f), 0.65f, p.TrainSilver);
                b.Beam(new Vector3(76, y, 287.8f), new Vector3(56, y + 20, 287.8f), 0.65f, p.TrainSilver);
            }
            for (int antenna = 0; antenna < 2; antenna++)
                b.Box("Hancock antenna", new Vector3(60 + antenna * 12, 92, 295), new Vector3(0.5f, 16, 0.5f), p.TrainSilver);

            // Two scalloped stacks suggest Marina City's round balconies.
            for (int tower = 0; tower < 2; tower++)
            for (int floor = 0; floor < 15; floor++)
            {
                float x = 25 + tower * 14;
                b.Cylinder(new Vector3(x, floor * 2.4f + 1.2f, 205), 3.8f, 2.4f, p.Window);
                b.Cylinder(new Vector3(x, floor * 2.4f + 2.3f, 205), 5.2f, 0.45f, p.Limestone);
            }
            for (int index = 0; index < 14; index++)
            {
                float x = -135 + index * 20;
                if (Mathf.Abs(x) < 18) continue;
                float height = 23 + (index * 13 % 38);
                b.Box("Distant glass skyline", new Vector3(x, height / 2, 320 + index % 3 * 12), new Vector3(14, height, 14), index % 2 == 0 ? p.BuildingA : p.BuildingB);
            }
            // Cloud clusters are low-poly geometry, generated once with the skyline.
            for (int cluster = 0; cluster < 5; cluster++)
            for (int puff = 0; puff < 3; puff++)
                b.Ellipsoid(new Vector3(-175 + cluster * 85 + puff * 17, 85 + cluster % 2 * 18 + puff % 2 * 4, 350), new Vector3(24, 8 + puff * 3, 12), p.Cloud);
            b.Finish(false);
        }
    }

    /// <summary>One mesh per material per block, with explicit lifetime ownership.</summary>
    internal sealed class SceneryMeshBuilder
    {
        private sealed class Geometry
        {
            public readonly List<Vector3> Vertices = new List<Vector3>();
            public readonly List<Vector3> Normals = new List<Vector3>();
            public readonly List<int> Triangles = new List<int>();
        }
        private readonly Transform parent;
        private readonly Dictionary<Material, Geometry> geometry = new Dictionary<Material, Geometry>();
        public SceneryMeshBuilder(Transform parent) { this.parent = parent; }
        private void Triangle(Vector3 a, Vector3 b, Vector3 c, Material material)
        {
            if (!geometry.TryGetValue(material, out Geometry g)) geometry.Add(material, g = new Geometry());
            int start = g.Vertices.Count;
            Vector3 normal = Vector3.Cross(b - a, c - a).normalized;
            g.Vertices.Add(a); g.Vertices.Add(b); g.Vertices.Add(c);
            g.Normals.Add(normal); g.Normals.Add(normal); g.Normals.Add(normal);
            g.Triangles.Add(start); g.Triangles.Add(start + 1); g.Triangles.Add(start + 2);
        }
        public void Box(string name, Vector3 center, Vector3 size, Material material, Quaternion? rotation = null)
        {
            Quaternion r = rotation ?? Quaternion.identity;
            Vector3 x = r * new Vector3(size.x / 2, 0, 0);
            Vector3 y = r * new Vector3(0, size.y / 2, 0);
            Vector3 z = r * new Vector3(0, 0, size.z / 2);
            Face(center + x, -z, y, material); Face(center - x, z, y, material);
            Face(center + y, x, -z, material); Face(center - y, x, z, material);
            Face(center + z, x, y, material); Face(center - z, -x, y, material);
        }
        private void Face(Vector3 c, Vector3 u, Vector3 v, Material m)
        {
            Triangle(c - u - v, c + u - v, c + u + v, m);
            Triangle(c - u - v, c + u + v, c - u + v, m);
        }
        public void Beam(Vector3 from, Vector3 to, float thickness, Material p)
        {
            Box("Steel brace", (from + to) / 2, new Vector3(thickness, (to - from).magnitude, thickness), p, Quaternion.FromToRotation(Vector3.up, to - from));
        }
        public void Crown(Vector3 center, Vector3 radius, Material material)
        {
            for (int i = 0; i < 8; i++)
            {
                float angle = i * Mathf.PI / 4;
                float next = (i + 1) * Mathf.PI / 4;
                Vector3 a = center + new Vector3(Mathf.Cos(angle) * radius.x, 0, Mathf.Sin(angle) * radius.z);
                Vector3 b = center + new Vector3(Mathf.Cos(next) * radius.x, 0, Mathf.Sin(next) * radius.z);
                Triangle(center + Vector3.up * radius.y, b, a, material);
                Triangle(center - Vector3.up * radius.y * 0.7f, a, b, material);
            }
        }
        public void Star(Vector3 center, float radius, Material p)
        {
            for (int i = 0; i < 12; i++)
            {
                float a = i * Mathf.PI / 6, b = (i + 1) * Mathf.PI / 6;
                Vector3 v1 = center + new Vector3(Mathf.Sin(a), Mathf.Cos(a), 0) * radius * (i % 2 == 0 ? 1 : 0.4f);
                Vector3 v2 = center + new Vector3(Mathf.Sin(b), Mathf.Cos(b), 0) * radius * (i % 2 == 0 ? 0.4f : 1);
                Triangle(center, v1, v2, p);
            }
        }
        public void Cylinder(Vector3 center, float radius, float height, Material material, Quaternion? rotation = null)
        {
            Quaternion r = rotation ?? Quaternion.identity;
            Vector3 up = r * Vector3.up * height / 2;
            for (int i = 0; i < 16; i++)
            {
                float a = i * Mathf.PI / 8, next = (i + 1) * Mathf.PI / 8;
                Vector3 v1 = r * new Vector3(Mathf.Cos(a), 0, Mathf.Sin(a)) * radius;
                Vector3 v2 = r * new Vector3(Mathf.Cos(next), 0, Mathf.Sin(next)) * radius;
                Triangle(center + up, center + up + v2, center + up + v1, material);
                Triangle(center - up, center - up + v1, center - up + v2, material);
                Triangle(center + v1 - up, center + v1 + up, center + v2 + up, material);
                Triangle(center + v1 - up, center + v2 + up, center + v2 - up, material);
            }
        }
        public void TaperedBox(Vector3 bottom, Vector2 bottomSize, Vector3 top, Vector2 topSize, Material material)
        {
            Vector3 a = bottom + new Vector3(-bottomSize.x / 2, 0, -bottomSize.y / 2);
            Vector3 b = bottom + new Vector3(bottomSize.x / 2, 0, -bottomSize.y / 2);
            Vector3 c = bottom + new Vector3(bottomSize.x / 2, 0, bottomSize.y / 2);
            Vector3 d = bottom + new Vector3(-bottomSize.x / 2, 0, bottomSize.y / 2);
            Vector3 e = top + new Vector3(-topSize.x / 2, 0, -topSize.y / 2);
            Vector3 f = top + new Vector3(topSize.x / 2, 0, -topSize.y / 2);
            Vector3 g = top + new Vector3(topSize.x / 2, 0, topSize.y / 2);
            Vector3 h = top + new Vector3(-topSize.x / 2, 0, topSize.y / 2);
            Quad(a, b, f, e, material); Quad(d, h, g, c, material);
            Quad(a, e, h, d, material); Quad(b, c, g, f, material);
            Quad(e, f, g, h, material); Quad(a, d, c, b, material);
        }
        private void Quad(Vector3 a, Vector3 b, Vector3 c, Vector3 d, Material material)
        {
            Triangle(a, c, b, material); Triangle(a, d, c, material);
        }
        public void Ellipsoid(Vector3 center, Vector3 radius, Material material)
        {
            for (int ring = 0; ring < 6; ring++)
            for (int slice = 0; slice < 12; slice++)
            {
                Vector3 a = SpherePoint(ring, slice, radius) + center;
                Vector3 b = SpherePoint(ring + 1, slice, radius) + center;
                Vector3 c = SpherePoint(ring + 1, slice + 1, radius) + center;
                Vector3 d = SpherePoint(ring, slice + 1, radius) + center;
                Triangle(a, d, c, material);
                Triangle(a, c, b, material);
            }
        }
        private static Vector3 SpherePoint(int ring, int slice, Vector3 radius)
        {
            float latitude = ring * Mathf.PI / 6;
            float longitude = slice * Mathf.PI / 6;
            return Vector3.Scale(new Vector3(Mathf.Sin(latitude) * Mathf.Cos(longitude), Mathf.Cos(latitude), Mathf.Sin(latitude) * Mathf.Sin(longitude)), radius);
        }
        public void Finish(bool shadows = true)
        {
            var owner = parent.gameObject.AddComponent<SceneryMeshOwner>();
            foreach (var pair in geometry)
            {
                var mesh = new Mesh { name = "Chicago scenery", indexFormat = IndexFormat.UInt32 };
                mesh.SetVertices(pair.Value.Vertices);
                mesh.SetNormals(pair.Value.Normals);
                mesh.SetTriangles(pair.Value.Triangles, 0);
                mesh.RecalculateBounds();
                mesh.UploadMeshData(true);
                owner.Meshes.Add(mesh);
                var item = new GameObject(pair.Key.name + " scenery");
                item.transform.SetParent(parent, false);
                item.AddComponent<MeshFilter>().sharedMesh = mesh;
                var renderer = item.AddComponent<MeshRenderer>();
                renderer.sharedMaterial = pair.Key;
                renderer.shadowCastingMode = shadows ? ShadowCastingMode.On : ShadowCastingMode.Off;
                renderer.receiveShadows = shadows;
            }
        }
    }
}
