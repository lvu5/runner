using System.Collections.Generic;
using UnityEngine;

namespace InfiniteRunner
{
    public sealed class TrackManager : MonoBehaviour
    {
        [SerializeField] private int activeSegmentCount = 9;
        [SerializeField] private float segmentLength = 30f;
        [SerializeField] private float laneWidth = 2.75f;
        [SerializeField] private float recycleDistanceBehindPlayer = 12f;

        private readonly Queue<TrackSegment> activeSegments = new Queue<TrackSegment>();

        private RunnerController player;
        private GameManager gameManager;
        private PrototypePalette palette;
        private float nextSpawnZ;
        private int nextSegmentSerial;

        public CtaRoutePhase CurrentRoutePhase => player == null ? CtaRoutePhase.Street :
            CtaRoofRoute.PhaseForSegment(Mathf.FloorToInt(player.transform.position.z / segmentLength));

        public string RouteLocation
        {
            get
            {
                int serial = player == null ? 0 : Mathf.FloorToInt(player.transform.position.z / segmentLength);
                CtaRoutePhase phase = CtaRoofRoute.PhaseForSegment(serial);
                if (phase == CtaRoutePhase.Street)
                    return CtaRoofRoute.PhaseForSegment(serial + 1) == CtaRoutePhase.Ascent
                        ? "CTA AHEAD / RAMPS " + CtaRoofRoute.LaneHint(CtaRoofRoute.LaneMaskForSegment(serial + 1))
                        : "CHICAGO / THE LOOP";
                if (phase == CtaRoutePhase.Ascent)
                    return "CTA / RAMPS " + CtaRoofRoute.LaneHint(CtaRoofRoute.LaneMaskForSegment(serial));
                return phase == CtaRoutePhase.Descent ? "CTA / BACK TO THE STREET" : "CTA / ROOFTOP RUN";
            }
        }

        public void Configure(
            RunnerController runner,
            GameManager manager,
            PrototypePalette prototypePalette)
        {
            player = runner;
            gameManager = manager;
            palette = prototypePalette;
            BuildInitialTrack();
        }

        private void BuildInitialTrack()
        {
            float firstStartZ = -segmentLength;

            for (int index = 0; index < activeSegmentCount; index++)
            {
                GameObject segmentObject = new GameObject($"Track Segment {index:00}");
                segmentObject.transform.SetParent(transform, false);

                TrackSegment segment = segmentObject.AddComponent<TrackSegment>();
                segment.Initialize(index, segmentLength, laneWidth, gameManager, palette);
                segment.Place(firstStartZ + index * segmentLength, index - 1);
                activeSegments.Enqueue(segment);
            }

            nextSpawnZ = firstStartZ + activeSegmentCount * segmentLength;
            nextSegmentSerial = activeSegmentCount - 1;
        }

        private void Update()
        {
            if (player == null || activeSegments.Count == 0)
            {
                return;
            }

            while (activeSegments.Peek().EndZ < player.transform.position.z - recycleDistanceBehindPlayer)
            {
                TrackSegment recycled = activeSegments.Dequeue();
                recycled.Place(nextSpawnZ, nextSegmentSerial++);
                nextSpawnZ += segmentLength;
                activeSegments.Enqueue(recycled);
            }
        }
    }
}
