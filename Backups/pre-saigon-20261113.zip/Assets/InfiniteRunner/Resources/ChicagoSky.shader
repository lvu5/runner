Shader "InfiniteRunner/ChicagoSky"
{
    SubShader
    {
        Tags { "Queue"="Background" "RenderType"="Background" "PreviewType"="Skybox" }
        Cull Off ZWrite Off
        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"
            struct v2f { float4 vertex : SV_POSITION; float3 direction : TEXCOORD0; };
            v2f vert(float4 vertex : POSITION)
            {
                v2f o;
                o.vertex = UnityObjectToClipPos(vertex);
                o.direction = vertex.xyz;
                return o;
            }
            fixed4 frag(v2f i) : SV_Target
            {
                float3 d = normalize(i.direction);
                float elevation = saturate(d.y);
                float3 sky = lerp(float3(0.77, 0.89, 0.95), float3(0.24, 0.64, 0.92), pow(elevation, 0.55));
                float sun = dot(d, normalize(float3(-0.45, 0.3, 1)));
                sky = lerp(sky, float3(1, 0.95, 0.76), pow(saturate(sun), 85) * 0.25);
                sky = lerp(sky, float3(1, 0.98, 0.84), smoothstep(0.9987, 0.9991, sun));
                return fixed4(sky, 1);
            }
            ENDCG
        }
    }
    Fallback Off
}
